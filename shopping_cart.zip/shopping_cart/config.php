<?php

$conn = mysqli_connect('localhost','root','','shop_db') or die('connection failed');

?>