
function myFunction() {
  document.getElementById("myDIVa").style.backgroundColor = "Green";
}
