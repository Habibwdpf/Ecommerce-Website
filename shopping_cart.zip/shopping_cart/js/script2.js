
 let index=0;
    let st={records:[]};
    var U=$("#url").val();
    function display(){
            //st.records = localStorage.getItem('records');
            $.get(`${U}/getorder.php`,{},function(data){
        data=JSON.parse(data);
                st.records=data.records;
                //alert(data.total)
                $("#tot").html(data.total);
                let a="";   
                let i=0;    
                $.each(st.records, function(i, d){  
                    a+=`<tr "('${d?.id}','${d?.name}','${d?.number}','${d?.email}','${d?.method}','${d?.flat}','${d?.street}','${d?.city}','${d?.state}','${d?.country}','${d?.pin_code}','${d?.total_products}','${d?.total_price}','${i}')">
                    <td>${d.id}</td><td>${d.name}</td><td>${d.number}</td><td>${d.email}</td><td>${d.method}</td><td>${d.flat}</td><td>${d.street}</td><td>${d.city}</td><td>${d.state}</td><td>${d.country}</td><td>${d.pin_code}</td><td>${d.total_products}</td>
                   <td>${d.total_price}</td>
                    <td><button type="button" id="myDIVa"  onclick="add('${d.id}',event); myFunction();">Confirm Delivery</button></td></tr>`;//<td>${d.state}</td><td>${d.country}</td><td>${d.pin_code}</td><td>${d.total_products}</td>
                    i++;//i=i+1;
                }    );   
                $("#tb").html(a);
                
        });        
    }
    display();

    function add(i,event){
        event.stopPropagation();
        a=i;
        url=`${U}/insertorder.php?id=${a}`;
       $.get(url,{},function(data){
       });
       alert("Order Conferm")
        //st.records.splice(i,1);
        //localStorage.setItem('records', JSON.stringify(st.records));
    }
