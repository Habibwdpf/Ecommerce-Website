<header class="header">

   <div class="flex">

      <a href="" class="logo">Restaurant-- Admin Panel</a>
      
      <nav class="navbar">

         <a href="admin2.php">add products</a>
         <a href="index2.php">products</a>
         <a href="order.php">Order</a>
         <a href="confirmorder.php">Cofirm Delivery</a>
         <a href="http://localhost/PHP/Arif/shopping_cart/index.php" >Log out</a>
      </nav>

      <div id="menu-btn" class="fas fa-bars"></div>

   </div>

</header>