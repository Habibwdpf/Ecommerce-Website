


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<!-- custom css file link  -->
<link rel="stylesheet" href="css/style.css">
</head>
<style>

</style>
<body>
<div class="container">
<?php include 'header2.php'; ?>

    <div style="  background-color:silver;">
        <h1 class="text-center" style=" font:bold 44px 'Aleo';
	  text-shadow:1px 1px 15px #000;
	   color:black; text-align:center;
	   background-color:darkgray; 
	   padding: 20px;
	   margin: 0px 200px;
       border-radius: 10px;
	   ">Confirm Delivery</h1>
        <?php
if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
$url = "https://";
}else{
$url = "http://";
}
?>
<input type="hidden" id="url" value="<?=$url.$_SERVER['HTTP_HOST']. dirname($_SERVER['PHP_SELF']);?>"/>

           
<div>
<table class="table">
    <caption>Total Rows: <span id="tot"></span></caption>
    <thead>
        <th>id</th>
        <th>name</th>
        <th>number</th>
        <th>email</th>
        <th>method</th>
        <th>flat</th>
        <th>street</th>
        <th>city</th>
        <th>state</th>
        <th>country</th>
        <th>pin_code</th>
        <th>total_products</th>
        <th>total_price</th>
        
    </thead>
    <tbody id="tb">

    </tbody>
</table>
</div>
</div>
<script
src="https://code.jquery.com/jquery-1.12.4.min.js"
integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ="
crossorigin="anonymous"></script>
<script src="js/script4.js"></script>
</body>
</html>