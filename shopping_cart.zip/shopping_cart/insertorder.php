<?php
    header( 'Content-Type: text/html; charset=utf-8' );
    $arr=array(); 
    include("library.php");
    if( isset($_GET['id']) ){
        $a=new library();	
        $m=$a->db;
        $q="INSERT INTO confirm_delivery SELECT * FROM `order` WHERE id='{$_GET['id']}'";
        $r=$m->query($q);
        if(!$r)	{
            echo "{success:".mysqli_errno($m).", Query: $q}";		
        }
        else{
            echo '{success:true}';	  
        }
        }
        else{
            echo '{success:input query string}'; 
        }

        //http://localhost/MySQL/2023-09-04/deleteitem.php?id=1
    ?>