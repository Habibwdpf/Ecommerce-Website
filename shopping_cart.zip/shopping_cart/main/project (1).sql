-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2023 at 05:14 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `departmentcode` varchar(120) NOT NULL,
  `departmentname` varchar(100) DEFAULT NULL,
  `company` varchar(400) DEFAULT NULL,
  `show` varchar(200) DEFAULT NULL,
  `smalldept` varchar(100) DEFAULT NULL,
  `smallnamesl` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`departmentcode`, `departmentname`, `company`, `show`, `smalldept`, `smallnamesl`) VALUES
('1', 'moshla', 'ruchi', 'yes', 'biriyani moshla', 1),
('2', 'Food', 'TK', 'yes', 'fruits', 2),
('3', 'electricity', 'fivestar', 'yes', 'elec', 43),
('4', 'Hoshiary', 'Jamal Associates', '1', 'HOS', 44);

-- --------------------------------------------------------

--
-- Table structure for table `duereceive`
--

CREATE TABLE `duereceive` (
  `vrno` varchar(100) NOT NULL,
  `date` datetime DEFAULT NULL,
  `customername` varchar(200) DEFAULT NULL,
  `due` double DEFAULT NULL,
  `salevrno` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `duereceive`
--

INSERT INTO `duereceive` (`vrno`, `date`, `customername`, `due`, `salevrno`) VALUES
('V-001', '2023-09-10 00:00:00', 'habib Video', 1000, 'AC-00001'),
('V-002', '2023-09-10 00:00:00', 'habib video', 100, 'AC-00002'),
('V-003', '2023-09-10 00:00:00', 'aziz', 200, 'AC-00003');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `itemcode` varchar(200) NOT NULL,
  `group` varchar(80) DEFAULT NULL,
  `itemname` varchar(80) DEFAULT NULL,
  `purchaseprice` double DEFAULT NULL,
  `sellingprice` double DEFAULT NULL,
  `qty` double DEFAULT NULL,
  `rol` double DEFAULT NULL,
  `expiredate` datetime DEFAULT NULL,
  `suppliername` varchar(200) DEFAULT NULL,
  `departmentcode` varchar(50) DEFAULT NULL,
  `wholeprice` double DEFAULT NULL,
  `msu` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`itemcode`, `group`, `itemname`, `purchaseprice`, `sellingprice`, `qty`, `rol`, `expiredate`, `suppliername`, `departmentcode`, `wholeprice`, `msu`) VALUES
('1', 'petro', 'oil', 30, 50, 10, 15, '2023-09-04 00:00:00', 'murad', '2', 1000, '1'),
('12', 'a', 'sdf', 0, 0, 0, 10, '0000-00-00 00:00:00', '', '2', 0, ''),
('13', 'electricity', 'light', 50, 80, 500, 9, '0000-00-00 00:00:00', 'qazi', '3', 0, ''),
('2', 'hello', 'null', 100, 0, 100, 10, '0000-00-00 00:00:00', 'null', '2', 0, 'null'),
('20', 'madicin', 'seclo', 5, 6, 1000, 10, '0000-00-00 00:00:00', 'null', '2', 0, ''),
('22', 'sports', 'bat', 500, 650, 10, 15, '2023-09-04 00:00:00', 'sakib', '2', 550, ''),
('3', 'ohio', 'Potato', 100, 50, 100, 10, '0000-00-00 00:00:00', 'null', '2', 0, ''),
('4', 'bombay', 'canacur', 10, 15, 150, 10, '0000-00-00 00:00:00', 'null', '2', 0, ''),
('5', 'mashla', 'Arku', 20, 28, 24, 8, '0000-00-00 00:00:00', 'hadid', '1', 23, '2'),
('6', 'mashla', 'raduni', 10, 15, 500, 10, '0000-00-00 00:00:00', 'null', '1', 0, ''),
('7', 'mashla', 'biriani', 50, 65, 500, 15, '0000-00-00 00:00:00', 'null', '1', 0, ''),
('8', 'mashla', 'cotputi masla', 50, 65, 500, 20, '0000-00-00 00:00:00', 'null', '1', 0, ''),
('9', 'mashla', 'murgi masla', 50, 65, 500, 10, '0000-00-00 00:00:00', 'null', '1', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `operationlineitems`
--

CREATE TABLE `operationlineitems` (
  `vrno` varchar(100) NOT NULL,
  `slno` int(11) NOT NULL,
  `itemcode` varchar(100) DEFAULT NULL,
  `itemname` varchar(100) DEFAULT NULL,
  `qty` double DEFAULT NULL,
  `price` double DEFAULT NULL,
  `total` double DEFAULT NULL,
  `mode` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `operationlineitems`
--

INSERT INTO `operationlineitems` (`vrno`, `slno`, `itemcode`, `itemname`, `qty`, `price`, `total`, `mode`) VALUES
('AC-00008', 1, '3', 'Potato', -100, 50, -5000, 'sell'),
('AC-00008', 2, '1', 'oil', -10, 50, -500, 'sell'),
('AC-00009', 1, '3', 'Potato', -20, 50, -1000, 'sell'),
('AC-00011', 1, '1', 'oil', -2, 50, -100, 'sell'),
('AC-00012', 1, '4', 'canacur', -20, 15, -300, 'sell'),
('AC-00015', 1, '5', 'cinigura', -5, 15, -75, 'sell'),
('AC-00015', 2, '6', 'raduni', -8, 15, -120, 'sell'),
('AC-00015', 3, '7', 'biriani', -10, 65, -650, 'sell'),
('AC-00016', 1, '20', 'seclo', -20, 6, -120, 'sell'),
('AC-00017', 1, '20', 'seclo', -2, 6, -12, 'sell'),
('AC-00019', 1, '13', 'light', -10, 80, -800, 'sell'),
('AC-00020', 1, '13', 'light', -12, 80, -960, 'sell'),
('AC-00021', 1, '3', 'Potato', -1, 50, -50, 'sell'),
('AC-00021', 2, '4', 'canacur', -1, 15, -15, 'sell'),
('AC-00022', 1, '1', 'oil', -100, 50, -5000, 'sell'),
('AC-001', 1, '1', 'blood cbc', 1, 160, 160, 'sell'),
('AC-002', 2, '1', 'Xray', 1, 300, 300, 'purchase'),
('AC-003', 3, '1', 'Dna', 1, 1000, 1000, 'purchase'),
('GR-00006', 1, '1', 'potato', 1, 50, 50, 'purchase'),
('GR-00007', 1, '3', 'Potato', 1000, 50, 50000, 'purchase'),
('GR-00010', 1, '4', 'canacur', 10, 15, 150, 'purchase'),
('GR-00010', 2, '1', 'oil', 5, 50, 250, 'purchase'),
('GR-00013', 1, '4', 'canacur', 200, 15, 3000, 'purchase'),
('GR-00013', 2, '6', 'raduni', 1, 15, 15, 'purchase'),
('GR-00014', 1, '6', 'raduni', 20, 15, 300, 'purchase'),
('GR-00014', 2, '5', 'cinigura', 15, 15, 225, 'purchase'),
('GR-00014', 3, '7', 'biriani', 30, 65, 1950, 'purchase'),
('GR-00016', 1, '20', 'seclo', 50, 6, 300, 'purchase'),
('GR-00018', 1, '13', 'light', 100, 80, 8000, 'purchase');

-- --------------------------------------------------------

--
-- Table structure for table `operationtotal`
--

CREATE TABLE `operationtotal` (
  `vrno` varchar(100) NOT NULL,
  `customername` varchar(100) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `total` double DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `net` double DEFAULT NULL,
  `paid` double DEFAULT NULL,
  `due` double DEFAULT NULL,
  `mode` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `operationtotal`
--

INSERT INTO `operationtotal` (`vrno`, `customername`, `date`, `total`, `discount`, `net`, `paid`, `due`, `mode`) VALUES
('AC-00008', 'jamal', '2023-09-11 00:00:00', 5500, 50, 5450, 5400, 50, 'sell'),
('AC-00009', 'kamal', '2023-09-12 00:00:00', 1000, 0, 1000, 1000, 0, 'sell'),
('AC-00011', '', '2023-09-10 00:00:00', 100, 10, 90, 90, 0, 'sell'),
('AC-00012', '', '2023-09-10 00:00:00', 300, 20, 280, 280, 0, 'sell'),
('AC-00015', 'Habib', '2023-09-10 00:00:00', 845, 50, 795, 700, 95, 'sell'),
('AC-00016', '', '2023-09-14 00:00:00', 120, 1, 119, 119, 0, 'sell'),
('AC-00017', 'hasan', '2023-09-14 00:00:00', 12, 1, 11, 11, 0, 'sell'),
('AC-00019', '', '2023-09-17 00:00:00', 800, 10, 790, 790, 0, 'sell'),
('AC-00020', 'dablu', '2023-09-17 00:00:00', 960, 60, 900, 900, 0, 'sell'),
('AC-00021', '', '2023-09-19 00:00:00', 50, 5, 45, 10, 35, 'sell'),
('AC-00022', 'Habib Video', '2023-09-01 00:00:00', 5000, 0, 5000, 0, 5000, 'sell'),
('AC-001', 'Rofiq', '2023-05-05 00:00:00', -160, 0, 300, 300, 0, 'sell'),
('AC-003', 'mujib sir', '1975-05-05 00:00:00', 5300, 0, 5300, 300, 0, 'sell'),
('AC-005', 'habib youtube', '2023-05-05 00:00:00', 300, 0, 300, 300, 0, 'sell'),
('GR-00006', '', '2023-09-10 00:00:00', 50, 5, 45, 45, 0, 'purchase'),
('GR-00007', 'kamran', '2023-09-10 00:00:00', 50000, 500, 49500, 1500, 48000, 'purchase'),
('GR-00010', '', '2023-09-10 00:00:00', 400, 20, 380, 380, 0, 'purchase'),
('GR-00013', '', '2023-09-10 00:00:00', 3000, 20, 2980, 2000, 980, 'purchase'),
('GR-00014', '', '2023-09-10 00:00:00', 2475, 100, 2375, 2000, 375, 'purchase'),
('GR-00016', '', '2023-09-14 00:00:00', 300, 10, 290, 290, 0, 'purchase'),
('GR-00018', 'hablu', '2023-09-17 00:00:00', 8000, 100, 7900, 7900, 0, 'purchase');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `name`, `position`) VALUES
(1, 'admin', 'admin', 'Admin', 'admin'),
(2, 'cashier', 'cashier', 'Cashier Pharmacy', 'Cashier'),
(3, 'admin', 'admin123', 'Administrator', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`departmentcode`);

--
-- Indexes for table `duereceive`
--
ALTER TABLE `duereceive`
  ADD PRIMARY KEY (`vrno`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`itemcode`),
  ADD KEY `departmentCode` (`departmentcode`);

--
-- Indexes for table `operationlineitems`
--
ALTER TABLE `operationlineitems`
  ADD PRIMARY KEY (`vrno`,`slno`),
  ADD KEY `itemcode` (`itemcode`);

--
-- Indexes for table `operationtotal`
--
ALTER TABLE `operationtotal`
  ADD PRIMARY KEY (`vrno`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`departmentcode`) REFERENCES `department` (`departmentcode`);

--
-- Constraints for table `operationlineitems`
--
ALTER TABLE `operationlineitems`
  ADD CONSTRAINT `operationlineitems_ibfk_1` FOREIGN KEY (`itemcode`) REFERENCES `items` (`itemcode`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
