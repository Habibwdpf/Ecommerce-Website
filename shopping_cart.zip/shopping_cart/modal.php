<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<style>
 .modal-content{
  width: 100%;
  background: #f2f2f2;
 }
.form11{
  font-size: 30px;
 
}
.input-prepend{
  display: flex;
  justify-content: center;
}
.qwe{
   width: 20%;
  display: flex;
  justify-content: center;
}
.btn1{
   width: 100%;
   justify-content: center;

}
.modal-footer{
   width: 15%;
   justify-content: center;
}
</style>
<body>

<div  >
  <h2>Modal Example</h2>
  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" >
        <div id="login">
            <?php
            if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
                foreach($_SESSION['ERRMSG_ARR'] as $msg) {
                    echo '<div style="color: red; text-align: center; ">',$msg,'</div><br>'; 
                }
                unset($_SESSION['ERRMSG_ARR']);
            }
            ?>
            
            <form  action="login.php" method="post" class="form11">
                        <h2 class="text-primary" ><center>Log-in Page</center></h2>
                    <br>
            
                    
            <div class="input-prepend">
                    <span style="height:30px; width:25px;" class="add-on"><i class="icon-user icon-2x"></i></span><input style="height:40px;" type="text" name="username" Placeholder="Username" required/><br>
            </div>
            <div class="input-prepend ">
                <span style="height:30px; width:25px;" class="add-on"><i class="icon-lock icon-2x"></i></span><input type="password" style="height:40px;" name="password" Placeholder="Password" required/><br>
                    </div>
                    <div class="qwe">
                     <button class="btn1 btn-large btn-primary" href="dashboard.html" type="submit"><i class="icon-signin icon-large"></i> Login</button>
            </div>
                     </form>
            
                     <div class="modal-footer">
          <button type="button" class="btn btn-default  btn-danger" data-dismiss="modal">Close</button>
        </div>
                    </div>
            </div>
            </div>
            </div>
      
      </div>
      
    </div>
  </div>
  
</div>

</body>
</html>
